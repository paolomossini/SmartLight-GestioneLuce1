/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hello;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import com.google.gson.Gson;

/**
 * REST Web Service
 *
 * @author ricca
 */
@Path("GestioneLuce")
public class GestioneLuce {

    Lampadina lampadina = new Lampadina();

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of Hello
     */
    public GestioneLuce() {
    }

    /**
     * Retrieves representation of an instance of hello.Hello
     *
     * @param request
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public String getJson(JsonMap ordine) {
       
        if (ordine.getAction().equals("accendi")) {
            lampadina.getGestione(true);
        } else if(ordine.getAction().equals("spegni")) {
            lampadina.getGestione(false);
        }

        return "{\"stato\":\"001\"}";
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String postJson(String request) {

        return request;//;"{\"id\":\"001\"}";
    }

    /**
     * PUT method for updating or creating an instance of Hello
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
