/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hello;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Lampadina {

    private boolean gestione;

    public boolean isGestione() {
        return gestione;
    }

    public void setGestione(boolean gestione) {
        this.gestione = gestione;
    }

    public void getGestione(boolean ordine) {
        if (ordine == true) {

            try {
                URL url = new URL("http://192.168.0.200/io.cgi?DOA1=0");
                InputStream is = url.openStream();
                try {

                } finally {
                    is.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {

            try {
                URL url = new URL("http://192.168.0.200/io.cgi?DOI1=0");
                InputStream is = url.openStream();
                try {

                } finally {
                    is.close();
                }

                //  BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

}
